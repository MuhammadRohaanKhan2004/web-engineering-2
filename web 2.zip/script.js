$(document).ready(function () {
    // Game 1: Rock, Paper, Scissors
    const choices = ["Rock", "Paper", "Scissors"];  // The three possible choices
    let player1Choice = null;
  
    // When a player clicks one of the choice buttons
    $(".choice").click(function () {
      // Get the player's choice
      player1Choice = $(this).data("choice");
  
      // Randomly choose for Player 2
      const player2Choice = choices[Math.floor(Math.random() * choices.length)];
  
      // Highlight the selected button
      $(".choice").removeClass("selected");
      $(this).addClass("selected");
  
      // Determine the result
      let result = "";
      if (player1Choice === player2Choice) {
        result = "It's a Tie!";
      } else if (
        (player1Choice === "Rock" && player2Choice === "Scissors") ||
        (player1Choice === "Scissors" && player2Choice === "Paper") ||
        (player1Choice === "Paper" && player2Choice === "Rock")
      ) {
        result = "Player 1 Wins!";
      } else {
        result = "Player 2 Wins!";
      }
  
      // Display the result on the page
      $("#rps-result").text(`Player 1: ${player1Choice}, Player 2: ${player2Choice}. ${result}`);
    });
  
    // Game 2: Guess the Number
    let randomNumber = Math.floor(Math.random() * 100) + 1; // Generate a random number between 1 and 100
    let attempts = 10; // Set the number of attempts
  
    // Display the initial number of attempts
    $("#attempts-remaining").text(attempts);
  
    // When the user clicks the 'Submit Guess' button
    $("#guess-btn").click(function () {
      // If no attempts are left, disable guessing
      if (attempts === 0) {
        return;
      }
  
      // Get the player's guess from the input field
      const guess = parseInt($("#guess-input").val());
  
      // Check if the input is a valid number
      if (isNaN(guess)) {
        $("#feedback").text("Please enter a valid number.");
        return;
      }
  
      attempts--; // Decrease the number of attempts
      $("#attempts-remaining").text(attempts);
  
      // Provide feedback based on the player's guess
      if (guess === randomNumber) {
        $("#feedback").text("Congratulations! You guessed it!");
        $("#guess-btn").prop("disabled", true); // Disable the guess button once the game is over
      } else if (guess > randomNumber) {
        $("#feedback").text("Too High");
      } else {
        $("#feedback").text("Too Low");
      }
  
      // If attempts run out and the player hasn't guessed correctly
      if (attempts === 0 && guess !== randomNumber) {
        $("#feedback").text(`Game Over! The correct number was ${randomNumber}.`);
        $("#guess-btn").prop("disabled", true); // Disable the 'Submit Guess' button
      }
  
      // Clear the input field after the guess is submitted
      $("#guess-input").val('');
    });
  
    // When the user clicks the 'Restart Game' button
    $("#restart-btn").click(function () {
      // Reset the game state
      randomNumber = Math.floor(Math.random() * 100) + 1; // Generate a new random number
      attempts = 10; // Reset the number of attempts
      $("#attempts-remaining").text(attempts);
      $("#feedback").text(""); // Clear feedback message
      $("#guess-input").val(""); // Clear the guess input field
      $("#guess-btn").prop("disabled", false); // Enable the 'Submit Guess' button again
    });
  });
  